// FIX: Import React to resolve 'Cannot find namespace React' error.
import React from 'react';

export enum Tab {
  Workouts = 'Workouts',
  BodyAI = 'Body AI',
  CalorieAI = 'Calorie AI',
  Progress = 'Progress',
  Profile = 'Profile',
}

export enum WorkoutCategory {
  Calisthenics = 'Calisthenia',
  Gym = 'Academia',
  Hybrid = 'Híbrido',
  Home = 'Casa'
}

export interface Exercise {
  id: string;
  name: string;
  muscleGroup: string;
  category: WorkoutCategory;
  execution: string[];
  tips: string[];
  adaptations: {
    beginner: string;
    intermediate: string;
    advanced: string;
  };
  commonErrors: string[];
  videoUrl?: string; // Placeholder for video asset
}

export interface Workout {
  id: string;
  name: string;
  category: WorkoutCategory;
  exercises: { exerciseId: string; sets: string; reps: string; rest: string }[];
  duration: number; // in minutes
}

export interface BodyAnalysis {
  proportions: string;
  weakPoints: string[];
  strongPoints: string[];
  estimatedBodyFat: string;
  plan: {
    '30-day': string;
    '60-day': string;
    '90-day': string;
  };
}

export interface FoodItem {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface FoodAnalysis {
  items: FoodItem[];
  totalCalories: number;
  totalMacros: {
    protein: number;
    carbs: number;
    fat: number;
  };
  suggestions: string[];
}

export interface Badge {
    id: string;
    name: string;
    description: string;
    unlocked: boolean;
    icon: React.ReactNode;
}