
import React from 'react';
import Button from '../ui/Button';
import { TargetIcon } from '../ui/Icons';

interface LandingPageProps {
  onLaunchApp: () => void;
}

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="bg-gray-900/50 border border-gray-800 p-6 rounded-xl backdrop-blur-sm transform hover:scale-105 hover:border-blue-500 transition-all duration-300">
        <div className="flex items-center space-x-4 mb-3">
            <div className="bg-blue-500/20 p-2 rounded-lg text-blue-400">
                {icon}
            </div>
            <h3 className="font-rajdhani text-2xl font-bold">{title}</h3>
        </div>
        <p className="text-gray-400">{description}</p>
    </div>
);


const LandingPage: React.FC<LandingPageProps> = ({ onLaunchApp }) => {
  return (
    <div className="bg-black text-white min-h-screen">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/50 backdrop-blur-md border-b border-gray-900">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 68 83" xmlns="http://www.w3.org/2000/svg"><path d="M44.5736 10.9839C48.0441 7.51338 52.8833 5.48383 58.0019 5.48383C63.1205 5.48383 67.9597 7.51338 71.4302 10.9839C74.9007 14.4544 76.9303 19.2936 76.9303 24.4122V58.5878C76.9303 63.7064 74.9007 68.5456 71.4302 72.0161C67.9597 75.4866 63.1205 77.5162 58.0019 77.5162C52.8833 77.5162 48.0441 75.4866 44.5736 72.0161L13.5698 41.0124C10.0993 37.5418 8.06972 32.7027 8.06972 27.5841C8.06972 22.4655 10.0993 17.6263 13.5698 14.1558L44.5736 10.9839Z" transform="translate(-8.06972, 0)" fill="url(#fitgoal-logo-gradient-lp)" /><defs><linearGradient id="fitgoal-logo-gradient-lp" x1="8.06972" y1="41.5" x2="76.9303" y2="41.5" gradientUnits="userSpaceOnUse"><stop stopColor="#3B82F6"/><stop offset="1" stopColor="#8B5CF6"/></linearGradient></defs></svg>
            <h1 className="text-2xl font-rajdhani font-bold">FitGoal</h1>
          </div>
          <Button onClick={onLaunchApp} variant="secondary" className="px-4 py-2 text-base">ENTRAR</Button>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="pt-32 pb-20 text-center relative overflow-hidden bg-grid-gray-900">
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black to-black"></div>
            <div className="absolute inset-0 [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_60%,transparent_100%)]"></div>
            <div className="container mx-auto px-6 relative z-10">
                <h2 className="font-rajdhani text-5xl md:text-7xl font-bold tracking-tighter leading-tight animate-fade-in" style={{ animationDelay: '200ms' }}>
                    O MÉTODO DE TREINO QUE VAI <br/>
                    <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-500 neon-text-blue">TRANSFORMAR SEU FÍSICO</span>
                </h2>
                <p className="mt-6 text-lg md:text-xl text-gray-300 max-w-3xl mx-auto animate-fade-in" style={{ animationDelay: '400ms' }}>
                    Chega de treinar sem ver resultados. Com a IA do FitGoal, você terá um plano de 30, 60 ou 90 dias para ganhar de 5 a 12kg de massa muscular.
                </p>
                <div className="mt-10 animate-fade-in" style={{ animationDelay: '600ms' }}>
                    <Button onClick={onLaunchApp} className="text-xl px-10 py-4 transform hover:scale-105">
                        SIM! QUERO MUDAR MEU FÍSICO!
                    </Button>
                </div>
            </div>
        </section>

        {/* Social Proof */}
        <section className="py-12 bg-black">
            <div className="container mx-auto px-6">
                <h3 className="font-rajdhani text-center text-3xl font-bold text-gray-400">RESULTADOS REAIS DE QUEM USA FITGOAL</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 mt-8">
                    <img src="https://picsum.photos/seed/fit1/400/400" alt="Transformation 1" className="rounded-lg grayscale hover:grayscale-0 transition-all duration-300"/>
                    <img src="https://picsum.photos/seed/fit2/400/400" alt="Transformation 2" className="rounded-lg grayscale hover:grayscale-0 transition-all duration-300"/>
                    <img src="https://picsum.photos/seed/fit3/400/400" alt="Transformation 3" className="rounded-lg grayscale hover:grayscale-0 transition-all duration-300"/>
                    <img src="https://picsum.photos/seed/fit4/400/400" alt="Transformation 4" className="rounded-lg grayscale hover:grayscale-0 transition-all duration-300"/>
                </div>
            </div>
        </section>

        {/* For you section */}
        <section className="py-20 bg-gray-900/40">
            <div className="container mx-auto px-6 text-center">
                 <h2 className="font-rajdhani text-4xl md:text-5xl font-bold mb-4">ESSE APP É <span className="text-blue-400">PRA VOCÊ QUE:</span></h2>
                 <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto mt-12 text-left">
                    <FeatureCard icon={<TargetIcon className="w-6 h-6"/>} title="Não vê evolução" description="Treina, faz dieta mas sente que está estagnado e não vê progresso no espelho."/>
                    <FeatureCard icon={<TargetIcon className="w-6 h-6"/>} title="Quer recomposição" description="Busca queimar gordura e ganhar massa muscular ao mesmo tempo de forma eficiente."/>
                    <FeatureCard icon={<TargetIcon className="w-6 h-6"/>} title="É natural" description="Não quer ou não pode usar hormônios mas deseja um físico impressionante."/>
                    <FeatureCard icon={<TargetIcon className="w-6 h-6"/>} title="É iniciante" description="É novo na academia e não sabe por onde começar para ter resultados de verdade."/>
                    <FeatureCard icon={<TargetIcon className="w-6 h-6"/>} title="Tem pouco tempo" description="Precisa de treinos rápidos e eficientes que se encaixem em uma rotina corrida."/>
                     <FeatureCard icon={<TargetIcon className="w-6 h-6"/>} title="Busca motivação" description="Quer um sistema de gamificação que te mantenha focado e motivado todos os dias."/>
                 </div>
            </div>
        </section>
        
        {/* Price section */}
        <section id="oferta" className="py-20 text-center bg-black relative">
            <div className="absolute inset-0 bg-grid-gray-900 [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,#000_70%,transparent_100%)]"></div>
            <div className="container mx-auto px-6 relative z-10">
                <div className="max-w-2xl mx-auto bg-gray-900/50 border border-purple-500/50 rounded-2xl p-8 backdrop-blur-lg shadow-2xl shadow-purple-500/20">
                    <h3 className="font-rajdhani text-2xl font-bold text-purple-400">PREÇO ESPECIAL POR TEMPO LIMITADO</h3>
                    <p className="text-red-500 font-bold text-lg mt-2">R$199,90 DE DESCONTO!</p>
                    <p className="text-gray-400 mt-4">APENAS</p>
                    <p className="font-rajdhani text-6xl font-bold my-2">12x R$19,99</p>
                    <p className="text-gray-400">Ou R$199,90 à vista!</p>
                    <Button onClick={onLaunchApp} className="mt-8 text-xl px-10 py-4 w-full bg-purple-600 hover:bg-purple-500 shadow-purple-600/30 neon-glow-purple">
                        APROVEITAR AGORA!
                    </Button>
                    <p className="text-xs text-gray-500 mt-4">3 dias grátis. Cancele quando quiser.</p>
                </div>
            </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 bg-gray-900/50 border-t border-gray-800">
        <div className="container mx-auto px-6 text-center text-gray-500">
            <p>Copyright © 2024 FITGOAL – Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
