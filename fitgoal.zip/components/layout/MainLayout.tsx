
import React from 'react';
import BottomNav from './BottomNav';
import { Tab } from '../../types';

interface MainLayoutProps {
  children: React.ReactNode;
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children, activeTab, setActiveTab }) => {
  return (
    <div className="bg-black text-white min-h-screen pb-20">
      <main className="p-4 sm:p-6">{children}</main>
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};

export default MainLayout;
