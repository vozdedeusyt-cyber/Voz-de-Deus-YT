
import React from 'react';
import { Tab } from '../../types';
import { BarChartIcon, DumbbellIcon, PersonStandingIcon, SparklesIcon, UserIcon } from '../ui/Icons';

interface BottomNavProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const NavItem: React.FC<{
  tab: Tab;
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  icon: React.ReactNode;
}> = ({ tab, activeTab, setActiveTab, icon }) => {
  const isActive = activeTab === tab;
  return (
    <button
      onClick={() => {
          // TODO: Play interaction sound
          setActiveTab(tab)
        }
      }
      className="flex flex-col items-center justify-center w-full h-full transition-all duration-300 ease-in-out"
    >
      <div className={`transition-all duration-300 ${isActive ? 'scale-110 -translate-y-1' : 'scale-100'}`}>
        {React.cloneElement(icon as React.ReactElement, { className: `w-6 h-6 mb-1 transition-colors ${isActive ? 'text-blue-400' : 'text-gray-500'}` })}
      </div>
      <span className={`text-xs font-medium transition-all duration-300 ${isActive ? 'text-blue-400 font-bold' : 'text-gray-500'}`}>
        {tab}
      </span>
      {isActive && <div className="absolute bottom-0 w-8 h-1 bg-blue-400 rounded-full neon-glow-blue"></div>}
    </button>
  );
};


const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 h-20 bg-black/80 backdrop-blur-lg border-t border-gray-800/50 flex justify-around items-center z-50">
      <NavItem tab={Tab.Workouts} activeTab={activeTab} setActiveTab={setActiveTab} icon={<DumbbellIcon />} />
      <NavItem tab={Tab.BodyAI} activeTab={activeTab} setActiveTab={setActiveTab} icon={<PersonStandingIcon />} />
      <NavItem tab={Tab.CalorieAI} activeTab={activeTab} setActiveTab={setActiveTab} icon={<SparklesIcon />} />
      <NavItem tab={Tab.Progress} activeTab={activeTab} setActiveTab={setActiveTab} icon={<BarChartIcon />} />
      <NavItem tab={Tab.Profile} activeTab={activeTab} setActiveTab={setActiveTab} icon={<UserIcon />} />
    </div>
  );
};

export default BottomNav;
