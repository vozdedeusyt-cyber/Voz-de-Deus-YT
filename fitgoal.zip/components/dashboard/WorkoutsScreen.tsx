import React, { useState } from 'react';
import { Exercise, WorkoutCategory } from '../../types';
import { EXERCISES } from '../../constants/exercises';
import { ChevronRightIcon, ChevronLeftIcon, BookOpenIcon, ZapIcon, CheckCircleIcon, AlertTriangleIcon, DumbbellIcon } from '../ui/Icons';

const CategoryCard: React.FC<{ category: WorkoutCategory; description: string; imageUrl: string; onSelect: () => void; }> = ({ category, description, imageUrl, onSelect }) => (
    <div onClick={onSelect} className="relative rounded-xl overflow-hidden group cursor-pointer transform hover:scale-105 transition-transform duration-300">
        <img src={imageUrl} alt={category} className="w-full h-48 object-cover group-hover:blur-sm transition-all duration-300" />
        <div className="absolute inset-0 bg-black/60 group-hover:bg-black/80 transition-all duration-300 flex flex-col justify-end p-4">
            <h3 className="font-rajdhani text-2xl font-bold text-white">{category}</h3>
            <p className="text-gray-300 text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300">{description}</p>
        </div>
        <div className="absolute top-2 right-2 bg-blue-500/20 text-blue-300 text-xs font-bold px-2 py-1 rounded-full border border-blue-500/30">
            {EXERCISES.filter(ex => ex.category === category).length}+ EXERCÍCIOS
        </div>
    </div>
);

const ExerciseDetail: React.FC<{ exercise: Exercise; onBack: () => void }> = ({ exercise, onBack }) => {
    return (
        <div className="animate-fade-in">
            <button onClick={onBack} className="flex items-center space-x-2 text-blue-400 font-semibold mb-6">
                <ChevronLeftIcon className="w-5 h-5" />
                <span>Voltar para a lista</span>
            </button>
            <div className="bg-gray-900/50 rounded-xl border border-gray-800 overflow-hidden">
                <div className="h-48 bg-gray-800 flex items-center justify-center">
                    {/* Placeholder for video/image */}
                    <DumbbellIcon className="w-16 h-16 text-gray-600"/>
                </div>
                <div className="p-6 space-y-6">
                    <h1 className="font-rajdhani text-3xl font-bold text-blue-300">{exercise.name}</h1>
                    
                    <div>
                        <h2 className="font-rajdhani text-xl font-bold mb-3 flex items-center text-blue-400"><BookOpenIcon className="w-5 h-5 mr-2"/> Execução Passo a Passo</h2>
                        <ul className="space-y-2 list-decimal list-inside text-gray-300">
                            {exercise.execution.map((step, i) => <li key={i}>{step}</li>)}
                        </ul>
                    </div>
                    
                     <div>
                        <h2 className="font-rajdhani text-xl font-bold mb-3 flex items-center text-green-400"><CheckCircleIcon className="w-5 h-5 mr-2"/> Dicas Técnicas</h2>
                        <ul className="space-y-2 list-disc list-inside text-gray-300">
                            {exercise.tips.map((tip, i) => <li key={i}>{tip}</li>)}
                        </ul>
                    </div>

                    <div>
                        <h2 className="font-rajdhani text-xl font-bold mb-3 flex items-center text-yellow-400"><ZapIcon className="w-5 h-5 mr-2"/> Adaptações</h2>
                        <div className="space-y-2 text-gray-300">
                            <p><strong className="text-yellow-300">Iniciante:</strong> {exercise.adaptations.beginner}</p>
                            <p><strong className="text-yellow-300">Intermediário:</strong> {exercise.adaptations.intermediate}</p>
                            <p><strong className="text-yellow-300">Avançado:</strong> {exercise.adaptations.advanced}</p>
                        </div>
                    </div>

                     <div>
                        <h2 className="font-rajdhani text-xl font-bold mb-3 flex items-center text-red-400"><AlertTriangleIcon className="w-5 h-5 mr-2"/> Erros Comuns</h2>
                        <ul className="space-y-2 list-disc list-inside text-gray-300">
                            {exercise.commonErrors.map((error, i) => <li key={i}>{error}</li>)}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

const CategoryTabs: React.FC<{
  activeCategory: WorkoutCategory;
  onSelectCategory: (category: WorkoutCategory) => void;
}> = ({ activeCategory, onSelectCategory }) => {
  const categories = Object.values(WorkoutCategory);
  return (
    <div className="flex space-x-2 overflow-x-auto pb-2 -mx-4 px-4">
      {categories.map((category) => (
        <button
          key={category}
          onClick={() => onSelectCategory(category)}
          className={`px-4 py-2 rounded-full font-rajdhani font-semibold text-sm transition-all duration-300 whitespace-nowrap ${
            activeCategory === category
              ? 'bg-blue-500 text-white neon-glow-blue'
              : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
          }`}
        >
          {category}
        </button>
      ))}
    </div>
  );
};


const WorkoutsScreen: React.FC = () => {
    const [selectedCategory, setSelectedCategory] = useState<WorkoutCategory | null>(null);
    const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);

    const categoryInfo = {
        [WorkoutCategory.Calisthenics]: { 
            title: 'Calistenia', 
            description: 'Domine seu corpo. Força, controle e definição.' 
        },
        [WorkoutCategory.Gym]: { 
            title: 'Academia', 
            description: 'Hipertrofia máxima. Utilize equipamentos para construir o físico dos seus sonhos.' 
        },
        [WorkoutCategory.Hybrid]: { 
            title: 'Híbrido', 
            description: 'O melhor dos dois mundos. Combine calistenia e academia para resultados completos.' 
        },
        [WorkoutCategory.Home]: { 
            title: 'Casa', 
            description: 'Seu treino, suas regras. Planos adaptados para os equipamentos que você tem em casa.'
        },
    };

    if (selectedExercise) {
        return <ExerciseDetail exercise={selectedExercise} onBack={() => setSelectedExercise(null)} />;
    }

    if (selectedCategory) {
        const exercises = EXERCISES.filter(ex => ex.category === selectedCategory);
        const info = categoryInfo[selectedCategory];

        return (
            <div className="space-y-6 animate-fade-in">
                <button onClick={() => setSelectedCategory(null)} className="flex items-center space-x-2 text-blue-400 font-semibold mb-2">
                    <ChevronLeftIcon className="w-5 h-5" />
                    <span>Todas as Categorias</span>
                </button>
                <header>
                    <h1 className="font-rajdhani text-4xl font-bold text-blue-400 neon-text-blue">{info.title}</h1>
                    <p className="text-gray-400 mt-1">{info.description}</p>
                </header>
                
                <CategoryTabs activeCategory={selectedCategory} onSelectCategory={setSelectedCategory} />

                <div className="space-y-3">
                    {exercises.length > 0 ? (
                        exercises.map(exercise => (
                            <div key={exercise.id} onClick={() => setSelectedExercise(exercise)} className="bg-gray-900/50 p-4 rounded-lg flex justify-between items-center cursor-pointer hover:bg-gray-800 transition-colors border border-gray-800">
                                <div>
                                    <h3 className="font-rajdhani font-semibold text-lg">{exercise.name}</h3>
                                    <p className="text-sm text-gray-500">{exercise.muscleGroup}</p>
                                </div>
                                <ChevronRightIcon className="w-6 h-6 text-gray-600" />
                            </div>
                        ))
                    ) : (
                        <div className="text-center py-10 text-gray-500">
                            <p>Nenhum exercício encontrado para esta categoria ainda.</p>
                            <p>Volte em breve!</p>
                        </div>
                    )}
                </div>
            </div>
        );
    }
    
    // Default view: Category Selection
    return (
        <div className="space-y-8 animate-fade-in">
        <header>
            <h1 className="font-rajdhani text-4xl font-bold text-blue-400 neon-text-blue">Treinos</h1>
            <p className="text-gray-400 mt-1">Escolha sua modalidade e comece a transformação.</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <CategoryCard 
                category={WorkoutCategory.Calisthenics} 
                description="Domine seu corpo. Força, controle e definição usando apenas o peso corporal."
                imageUrl="https://picsum.photos/seed/calisthenics/600/400"
                onSelect={() => setSelectedCategory(WorkoutCategory.Calisthenics)}
            />
            <CategoryCard 
                category={WorkoutCategory.Gym} 
                description="Hipertrofia máxima. Utilize equipamentos para construir o físico dos seus sonhos."
                imageUrl="https://picsum.photos/seed/gym/600/400"
                onSelect={() => setSelectedCategory(WorkoutCategory.Gym)}
            />
            <CategoryCard 
                category={WorkoutCategory.Hybrid} 
                description="O melhor dos dois mundos. Combine calistenia e academia para resultados completos."
                imageUrl="https://picsum.photos/seed/hybrid/600/400"
                onSelect={() => setSelectedCategory(WorkoutCategory.Hybrid)}
            />
            <CategoryCard 
                category={WorkoutCategory.Home} 
                description="Seu treino, suas regras. Planos adaptados para os equipamentos que você tem em casa."
                imageUrl="https://picsum.photos/seed/home/600/400"
                onSelect={() => setSelectedCategory(WorkoutCategory.Home)}
            />
        </div>
        </div>
    );
};

export default WorkoutsScreen;