
import React from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Badge } from '../../types';
import { AwardIcon, DumbbellIcon, TargetIcon } from '../ui/Icons';


const mockProgressData = [
  { name: 'Sem 1', peso: 80, gordura: 18 },
  { name: 'Sem 2', peso: 79.5, gordura: 17.8 },
  { name: 'Sem 3', peso: 79, gordura: 17.5 },
  { name: 'Sem 4', peso: 78.8, gordura: 17.2 },
];

const mockBadges: Badge[] = [
    { id: '1', name: 'Iniciado', description: 'Complete seu primeiro treino.', unlocked: true, icon: <DumbbellIcon/> },
    { id: '2', name: 'Consistência I', description: 'Treine por 7 dias seguidos.', unlocked: true, icon: <AwardIcon/> },
    { id: '3', name: 'Guerreiro da Manhã', description: 'Complete 10 treinos antes das 8h.', unlocked: false, icon: <DumbbellIcon/> },
    { id: '4', name: 'Foco Total', description: 'Siga seu plano por 30 dias.', unlocked: false, icon: <TargetIcon/> }
];

const ProgressScreen: React.FC = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h1 className="font-rajdhani text-4xl font-bold text-yellow-400 neon-text-yellow">Progresso</h1>
        <p className="text-gray-400 mt-1">Visualize sua evolução e conquistas.</p>
      </header>

      {/* Level Up & Streak */}
      <div className="text-center bg-gray-900/50 p-6 rounded-xl border border-yellow-500/30">
        <p className="font-rajdhani text-lg text-yellow-300">NÍVEL 5</p>
        <div className="w-full bg-gray-700 rounded-full h-2.5 my-2">
            <div className="bg-gradient-to-r from-yellow-500 to-orange-500 h-2.5 rounded-full" style={{width: '45%'}}></div>
        </div>
        <p className="text-sm text-gray-400">250/600 XP para o próximo nível</p>
        <div className="mt-4 text-2xl font-bold">🔥 <span className="text-orange-400">12</span> Dias de Streak!</div>
      </div>
      
      {/* Photo Comparison */}
       <div>
        <h2 className="font-rajdhani text-2xl font-bold mb-4">Fotos Comparativas</h2>
        <div className="grid grid-cols-2 gap-4">
            <div className="relative">
                <img src="https://picsum.photos/seed/before/400/600" alt="Before" className="rounded-lg"/>
                <p className="absolute bottom-2 left-2 bg-black/50 px-2 py-1 rounded text-sm">Início</p>
            </div>
            <div className="relative">
                <img src="https://picsum.photos/seed/after/400/600" alt="After" className="rounded-lg"/>
                <p className="absolute bottom-2 left-2 bg-black/50 px-2 py-1 rounded text-sm">Atual</p>
            </div>
        </div>
      </div>

      {/* Charts */}
      <div>
        <h2 className="font-rajdhani text-2xl font-bold mb-4">Evolução do Peso (kg)</h2>
        <div className="h-64 bg-gray-900/50 p-4 rounded-xl border border-gray-800">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={mockProgressData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" domain={['dataMin - 1', 'dataMax + 1']}/>
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }} />
              <Line type="monotone" dataKey="peso" stroke="#FBBF24" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Badges */}
      <div>
        <h2 className="font-rajdhani text-2xl font-bold mb-4">Conquistas</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {mockBadges.map(badge => (
                <div key={badge.id} className={`p-4 rounded-lg flex flex-col items-center text-center transition-opacity ${badge.unlocked ? 'bg-yellow-500/20 border border-yellow-500/50' : 'bg-gray-800 opacity-50'}`}>
                    <div className={`w-12 h-12 flex items-center justify-center rounded-full ${badge.unlocked ? 'bg-yellow-500/30 text-yellow-300' : 'bg-gray-700 text-gray-500'}`}>
                        {React.cloneElement(badge.icon as React.ReactElement, { className: 'w-6 h-6' })}
                    </div>
                    <h3 className="font-bold mt-2 text-sm">{badge.name}</h3>
                    <p className="text-xs text-gray-400">{badge.description}</p>
                </div>
            ))}
        </div>
      </div>

    </div>
  );
};

export default ProgressScreen;
