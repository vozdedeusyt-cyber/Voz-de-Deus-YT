
import React, { useState, useRef } from 'react';
import { analyzeBody } from '../../services/geminiService';
import { BodyAnalysis } from '../../types';
import Button from '../ui/Button';
import LoadingSpinner from '../ui/LoadingSpinner';
import { CameraIcon } from '../ui/Icons';

const BodyAIScreen: React.FC = () => {
  const [photos, setPhotos] = useState<(File | null)[]>([null, null, null]);
  const [previews, setPreviews] = useState<(string | null)[]>([null, null, null]);
  const [isLoading, setIsLoading] = useState(false);
  const [analysis, setAnalysis] = useState<BodyAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fileInputRefs = [useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null)];

  const handleFileChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const newPhotos = [...photos];
      newPhotos[index] = file;
      setPhotos(newPhotos);

      const newPreviews = [...previews];
      newPreviews[index] = URL.createObjectURL(file);
      setPreviews(newPreviews);
    }
  };

  const triggerFileInput = (index: number) => {
    fileInputRefs[index].current?.click();
  };

  const handleAnalyze = async () => {
    if (photos.some(p => p === null)) {
      setError("Por favor, envie as 3 fotos para análise.");
      return;
    }
    setError(null);
    setIsLoading(true);
    setAnalysis(null);
    try {
      const result = await analyzeBody(photos.filter(p => p !== null) as File[]);
      setAnalysis(result);
    } catch (err) {
      setError("Ocorreu um erro ao analisar suas fotos. Tente novamente.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const PhotoUploadBox: React.FC<{ index: number; label: string }> = ({ index, label }) => (
    <div
      onClick={() => triggerFileInput(index)}
      className="relative aspect-square w-full border-2 border-dashed border-gray-600 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-gray-900 transition-all"
    >
      <input
        type="file"
        accept="image/*"
        ref={fileInputRefs[index]}
        onChange={(e) => handleFileChange(index, e)}
        className="hidden"
      />
      {previews[index] ? (
        <img src={previews[index]} alt={label} className="absolute inset-0 w-full h-full object-cover rounded-lg" />
      ) : (
        <>
          <CameraIcon className="w-10 h-10 text-gray-500 mb-2" />
          <span className="text-sm font-semibold text-gray-400">{label}</span>
        </>
      )}
    </div>
  );

  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h1 className="font-rajdhani text-4xl font-bold text-purple-400 neon-text-purple">IA Corporal</h1>
        <p className="text-gray-400 mt-1">Envie 3 fotos e receba uma análise completa e um plano de 90 dias.</p>
      </header>

      {!analysis && (
        <div className="bg-gray-900/50 p-6 rounded-xl border border-gray-800">
          <div className="grid grid-cols-3 gap-4">
            <PhotoUploadBox index={0} label="Frente" />
            <PhotoUploadBox index={1} label="Lado" />
            <PhotoUploadBox index={2} label="Costas" />
          </div>
          {error && <p className="text-red-500 text-center mt-4">{error}</p>}
          <Button onClick={handleAnalyze} disabled={isLoading} className="w-full mt-6">
            {isLoading ? 'Analisando...' : 'Analisar Meu Corpo'}
          </Button>
        </div>
      )}

      {isLoading && <LoadingSpinner text="Analisando seu físico..." />}

      {analysis && (
        <div className="space-y-6 p-6 bg-gray-900 rounded-xl border border-purple-500/30 animate-fade-in">
          <h2 className="font-rajdhani text-3xl font-bold text-center text-purple-300">Seu Relatório FitGoal</h2>
          
          <div className="space-y-4">
              <div>
                  <h3 className="font-rajdhani text-xl font-semibold mb-2 text-purple-400">Análise de Proporções</h3>
                  <p className="text-gray-300">{analysis.proportions}</p>
              </div>
              <div>
                  <h3 className="font-rajdhani text-xl font-semibold mb-2 text-purple-400">Gordura Corporal Estimada</h3>
                  <p className="text-3xl font-bold text-white neon-text-purple">{analysis.estimatedBodyFat}</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                      <h3 className="font-rajdhani text-xl font-semibold mb-2 text-green-400">Pontos Fortes</h3>
                      <ul className="list-disc list-inside space-y-1 text-green-300">
                          {analysis.strongPoints.map(p => <li key={p}>{p}</li>)}
                      </ul>
                  </div>
                  <div>
                      <h3 className="font-rajdhani text-xl font-semibold mb-2 text-yellow-400">Pontos a Desenvolver</h3>
                      <ul className="list-disc list-inside space-y-1 text-yellow-300">
                          {analysis.weakPoints.map(p => <li key={p}>{p}</li>)}
                      </ul>
                  </div>
              </div>
               <div>
                  <h3 className="font-rajdhani text-xl font-semibold mb-2 text-purple-400">Seu Plano de 90 Dias</h3>
                  <div className="space-y-3">
                      <p><strong className="text-gray-200">30 Dias:</strong> {analysis.plan['30-day']}</p>
                      <p><strong className="text-gray-200">60 Dias:</strong> {analysis.plan['60-day']}</p>
                      <p><strong className="text-gray-200">90 Dias:</strong> {analysis.plan['90-day']}</p>
                  </div>
              </div>
          </div>
          <Button onClick={() => setAnalysis(null)} variant="secondary" className="w-full mt-6">Analisar Novamente</Button>
        </div>
      )}
    </div>
  );
};

export default BodyAIScreen;
