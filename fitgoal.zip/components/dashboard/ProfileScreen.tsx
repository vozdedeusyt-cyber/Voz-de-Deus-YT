
import React from 'react';
import Button from '../ui/Button';

const ProfileScreen: React.FC = () => {
  return (
    <div className="space-y-8 animate-fade-in pb-8">
      <header className="text-center">
        <img src="https://picsum.photos/seed/avatar/128/128" alt="User Avatar" className="w-32 h-32 rounded-full mx-auto border-4 border-blue-500 neon-glow-blue"/>
        <h1 className="font-rajdhani text-3xl font-bold mt-4">Alex Hunter</h1>
        <p className="text-gray-400">Meta: Hipertrofia</p>
      </header>
      
      <div className="space-y-6">
        {/* Subscription */}
        <div className="bg-gray-900/50 p-6 rounded-xl border border-gray-800">
            <h2 className="font-rajdhani text-xl font-bold mb-3 text-blue-300">Assinatura</h2>
            <div className="flex justify-between items-center">
                <div>
                    <p className="font-semibold">FitGoal PRO</p>
                    <p className="text-sm text-gray-400">Próxima cobrança: 24/08/2024</p>
                </div>
                <Button variant="secondary" className="py-2 px-4 text-sm">Gerenciar</Button>
            </div>
        </div>

        {/* Home Equipment */}
        <div className="bg-gray-900/50 p-6 rounded-xl border border-gray-800">
            <h2 className="font-rajdhani text-xl font-bold mb-3 text-blue-300">Equipamentos em Casa</h2>
            <div className="grid grid-cols-2 gap-4">
                <label className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
                    <input type="checkbox" className="form-checkbox h-5 w-5 bg-gray-700 border-gray-600 text-blue-500 focus:ring-blue-500/50" defaultChecked/>
                    <span className="text-gray-300">Halteres</span>
                </label>
                 <label className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
                    <input type="checkbox" className="form-checkbox h-5 w-5 bg-gray-700 border-gray-600 text-blue-500 focus:ring-blue-500/50" />
                    <span className="text-gray-300">Barra Fixa</span>
                </label>
                 <label className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
                    <input type="checkbox" className="form-checkbox h-5 w-5 bg-gray-700 border-gray-600 text-blue-500 focus:ring-blue-500/50" defaultChecked/>
                    <span className="text-gray-300">Elásticos</span>
                </label>
                 <label className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
                    <input type="checkbox" className="form-checkbox h-5 w-5 bg-gray-700 border-gray-600 text-blue-500 focus:ring-blue-500/50" />
                    <span className="text-gray-300">Kettlebell</span>
                </label>
            </div>
        </div>

        {/* Settings */}
        <div className="bg-gray-900/50 p-6 rounded-xl border border-gray-800">
            <h2 className="font-rajdhani text-xl font-bold mb-3 text-blue-300">Preferências</h2>
             <div className="space-y-4">
                <div className="flex justify-between items-center">
                    <label htmlFor="notifications" className="text-gray-300">Notificações de Treino</label>
                    <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="notifications" className="sr-only peer" defaultChecked/>
                        <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                </div>
                 <div className="flex justify-between items-center">
                    <label htmlFor="sounds" className="text-gray-300">Sons e Vibrações</label>
                    <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="sounds" className="sr-only peer" defaultChecked/>
                        <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                </div>
             </div>
        </div>
        
        <Button variant="ghost" className="w-full text-red-400 hover:bg-red-500/10">Sair da Conta</Button>
      </div>
    </div>
  );
};

export default ProfileScreen;
