
import React, { useState, useRef } from 'react';
import { analyzeFood } from '../../services/geminiService';
import { FoodAnalysis } from '../../types';
import Button from '../ui/Button';
import LoadingSpinner from '../ui/LoadingSpinner';
import { CameraIcon } from '../ui/Icons';

const CalorieAIScreen: React.FC = () => {
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [analysis, setAnalysis] = useState<FoodAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhoto(file);
      setPreview(URL.createObjectURL(file));
      setAnalysis(null);
      setError(null);
    }
  };

  const handleAnalyze = async () => {
    if (!photo) {
      setError("Por favor, envie uma foto da sua refeição.");
      return;
    }
    setError(null);
    setIsLoading(true);
    setAnalysis(null);
    try {
      const result = await analyzeFood(photo);
      setAnalysis(result);
    } catch (err) {
      setError("Ocorreu um erro ao analisar sua refeição. Tente novamente.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h1 className="font-rajdhani text-4xl font-bold text-green-400 neon-text-green">Caloria IA</h1>
        <p className="text-gray-400 mt-1">Tire uma foto da sua refeição para contar calorias e macros.</p>
      </header>
      
      <div className="bg-gray-900/50 p-6 rounded-xl border border-gray-800 space-y-4">
        <div 
          onClick={() => fileInputRef.current?.click()} 
          className="relative w-full h-64 border-2 border-dashed border-gray-600 rounded-lg flex items-center justify-center cursor-pointer hover:border-green-500 hover:bg-gray-900 transition-all"
        >
          <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
          {preview ? (
            <img src={preview} alt="Meal preview" className="absolute inset-0 w-full h-full object-cover rounded-lg" />
          ) : (
            <div className="text-center">
              <CameraIcon className="w-12 h-12 text-gray-500 mx-auto mb-2" />
              <span className="text-md font-semibold text-gray-400">Clique para enviar uma foto</span>
            </div>
          )}
        </div>
        {error && <p className="text-red-500 text-center">{error}</p>}
        <Button onClick={handleAnalyze} disabled={isLoading} className="w-full bg-green-600 hover:bg-green-500 shadow-green-600/30 neon-glow-green focus:ring-green-500/50">
          {isLoading ? 'Analisando...' : 'Analisar Refeição'}
        </Button>
      </div>

      {isLoading && <LoadingSpinner text="Calculando calorias e macros..." />}

      {analysis && (
        <div className="space-y-6 p-6 bg-gray-900 rounded-xl border border-green-500/30 animate-fade-in">
          <h2 className="font-rajdhani text-3xl font-bold text-center text-green-300">Análise Nutricional</h2>
          
          <div className="text-center">
            <p className="text-gray-400">Total de Calorias</p>
            <p className="text-5xl font-bold text-white neon-text-green">{analysis.totalCalories} <span className="text-2xl">kcal</span></p>
          </div>

          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="font-semibold text-blue-400">Proteínas</p>
              <p className="text-2xl font-bold">{analysis.totalMacros.protein.toFixed(1)}g</p>
            </div>
            <div>
              <p className="font-semibold text-yellow-400">Carboidratos</p>
              <p className="text-2xl font-bold">{analysis.totalMacros.carbs.toFixed(1)}g</p>
            </div>
            <div>
              <p className="font-semibold text-red-400">Gorduras</p>
              <p className="text-2xl font-bold">{analysis.totalMacros.fat.toFixed(1)}g</p>
            </div>
          </div>
          
          <div>
            <h3 className="font-rajdhani text-xl font-semibold mb-2 text-green-400">Itens Identificados</h3>
            <ul className="space-y-2">
              {analysis.items.map((item, i) => (
                <li key={i} className="flex justify-between items-center bg-gray-800/50 p-3 rounded-lg">
                  <span className="text-gray-300">{item.name}</span>
                  <span className="font-bold text-white">{item.calories} kcal</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-rajdhani text-xl font-semibold mb-2 text-green-400">Sugestões da IA</h3>
            <ul className="list-disc list-inside space-y-1 text-gray-400">
              {analysis.suggestions.map((s, i) => <li key={i}>{s}</li>)}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default CalorieAIScreen;
