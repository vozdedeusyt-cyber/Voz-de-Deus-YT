
import React from 'react';

interface LoadingSpinnerProps {
  text?: string;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ text }) => {
  return (
    <div className="flex flex-col items-center justify-center space-y-4 my-8">
      <div className="w-16 h-16 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin neon-glow-blue"></div>
      {text && <p className="text-lg font-rajdhani font-semibold text-blue-300 animate-pulse">{text}</p>}
    </div>
  );
};

export default LoadingSpinner;
