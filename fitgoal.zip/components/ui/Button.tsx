
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost';
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', className = '', ...props }) => {
  const baseStyles = 'px-6 py-3 font-rajdhani font-bold text-lg rounded-lg transition-all duration-300 ease-in-out transform focus:outline-none focus:ring-4';

  const variantStyles = {
    primary: 'bg-blue-600 text-white hover:bg-blue-500 active:scale-95 focus:ring-blue-500/50 shadow-lg shadow-blue-600/30 neon-glow-blue',
    secondary: 'bg-gray-800 text-blue-300 border border-blue-500 hover:bg-gray-700 active:scale-95 focus:ring-blue-500/30',
    ghost: 'bg-transparent text-blue-400 hover:bg-blue-500/10 active:scale-95 focus:ring-blue-500/20',
  };

  return (
    <button
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;
