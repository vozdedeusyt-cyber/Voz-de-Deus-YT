
import React, { useState, useEffect } from 'react';
import LandingPage from './components/landing/LandingPage';
import MainLayout from './components/layout/MainLayout';
import WorkoutsScreen from './components/dashboard/WorkoutsScreen';
import BodyAIScreen from './components/dashboard/BodyAIScreen';
import CalorieAIScreen from './components/dashboard/CalorieAIScreen';
import ProgressScreen from './components/dashboard/ProgressScreen';
import ProfileScreen from './components/dashboard/ProfileScreen';
import { Tab } from './types';

const App: React.FC = () => {
  const [isAppLaunched, setIsAppLaunched] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>(Tab.Workouts);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2000); // Splash screen for 2 seconds

    return () => clearTimeout(timer);
  }, []);

  const handleLaunchApp = () => {
    setIsAppLaunched(true);
  };

  const renderContent = () => {
    switch (activeTab) {
      case Tab.Workouts:
        return <WorkoutsScreen />;
      case Tab.BodyAI:
        return <BodyAIScreen />;
      case Tab.CalorieAI:
        return <CalorieAIScreen />;
      case Tab.Progress:
        return <ProgressScreen />;
      case Tab.Profile:
        return <ProfileScreen />;
      default:
        return <WorkoutsScreen />;
    }
  };

  if (showSplash) {
    return (
      <div className="flex items-center justify-center h-screen bg-black">
        <div className="flex items-center space-x-4 animate-pulse">
            <svg className="w-20 h-20 text-white" fill="none" viewBox="0 0 68 83" xmlns="http://www.w3.org/2000/svg">
                <path d="M44.5736 10.9839C48.0441 7.51338 52.8833 5.48383 58.0019 5.48383C63.1205 5.48383 67.9597 7.51338 71.4302 10.9839C74.9007 14.4544 76.9303 19.2936 76.9303 24.4122V58.5878C76.9303 63.7064 74.9007 68.5456 71.4302 72.0161C67.9597 75.4866 63.1205 77.5162 58.0019 77.5162C52.8833 77.5162 48.0441 75.4866 44.5736 72.0161L13.5698 41.0124C10.0993 37.5418 8.06972 32.7027 8.06972 27.5841C8.06972 22.4655 10.0993 17.6263 13.5698 14.1558L44.5736 10.9839Z" transform="translate(-8.06972, 0)" fill="url(#fitgoal-logo-gradient)" />
                <defs>
                    <linearGradient id="fitgoal-logo-gradient" x1="8.06972" y1="41.5" x2="76.9303" y2="41.5" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#3B82F6"/>
                        <stop offset="1" stopColor="#8B5CF6"/>
                    </linearGradient>
                </defs>
            </svg>
            <h1 className="text-5xl font-rajdhani font-bold neon-text-blue">FitGoal</h1>
        </div>
      </div>
    );
  }

  if (!isAppLaunched) {
    return <LandingPage onLaunchApp={handleLaunchApp} />;
  }

  return (
    <MainLayout activeTab={activeTab} setActiveTab={setActiveTab}>
      {renderContent()}
    </MainLayout>
  );
};

export default App;
