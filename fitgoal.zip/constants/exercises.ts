
import { Exercise, WorkoutCategory } from '../types';

export const EXERCISES: Exercise[] = [
    // --- CALISTHENICS ---
    {
        id: 'cal-pushup',
        name: 'Push-up (Flexão)',
        muscleGroup: 'Peito',
        category: WorkoutCategory.Calisthenics,
        execution: [
            "Comece em uma posição de prancha alta, com as mãos um pouco mais afastadas que a largura dos ombros.",
            "Mantenha o corpo reto da cabeça aos calcanhares, ativando o core e os glúteos.",
            "Abaixe o corpo dobrando os cotovelos, mantendo-os próximos ao corpo, até que o peito quase toque o chão.",
            "Empurre o chão com força para retornar à posição inicial."
        ],
        tips: ["Mantenha os cotovelos em um ângulo de 45 graus em relação ao corpo, não abertos para os lados.", "Imagine que está 'aparafusando' as mãos no chão para ativar os músculos das costas e estabilizar os ombros."],
        adaptations: {
            beginner: "Faça com os joelhos no chão ou em uma superfície elevada (inclina-do).",
            intermediate: "Faça a flexão padrão no chão.",
            advanced: "Adicione pausas no fundo do movimento ou use um colete de peso."
        },
        commonErrors: ["Deixar o quadril cair.", "Abrir demais os cotovelos.", "Não descer o suficiente."]
    },
    {
        id: 'cal-pullup',
        name: 'Pull-up (Barra Fixa)',
        muscleGroup: 'Costas',
        category: WorkoutCategory.Calisthenics,
        execution: [
            "Segure a barra com as mãos um pouco mais afastadas que a largura dos ombros, com as palmas voltadas para a frente.",
            "Comece pendurado com os braços totalmente estendidos.",
            "Puxe o corpo para cima, focando em usar os músculos das costas, até que o queixo passe da barra.",
            "Abaixe o corpo de forma controlada até a posição inicial."
        ],
        tips: ["Retraia as escápulas (junte as omoplatas) antes de iniciar a puxada.", "Mantenha o core ativado para evitar balançar."],
        adaptations: {
            beginner: "Use um elástico de resistência para ajudar na subida ou faça a fase negativa (pule para cima e desça lentamente).",
            intermediate: "Faça a barra fixa padrão.",
            advanced: "Adicione peso com um cinto ou segure um halter com os pés."
        },
        commonErrors: ["Usar impulso (kipping) excessivo.", "Não estender completamente os braços na descida.", "Arquear as costas."]
    },
    {
        id: 'cal-squat',
        name: 'Bodyweight Squat (Agachamento Livre)',
        muscleGroup: 'Pernas',
        category: WorkoutCategory.Calisthenics,
        execution: [
            "Fique em pé com os pés na largura dos ombros, com os dedos levemente apontados para fora.",
            "Mantenha o peito para cima e o core ativado.",
            "Abaixe o quadril para trás e para baixo, como se estivesse sentando em uma cadeira.",
            "Desça até que as coxas fiquem pelo menos paralelas ao chão.",
            "Empurre o chão com os calcanhares para voltar à posição inicial."
        ],
        tips: ["Mantenha o peso nos calcanhares e no meio do pé.", "Não deixe os joelhos passarem muito da ponta dos pés ou caírem para dentro."],
        adaptations: {
            beginner: "Use uma cadeira ou banco como guia para a profundidade.",
            intermediate: "Faça o agachamento padrão com amplitude total.",
            advanced: "Faça agachamentos com salto (jump squats) ou progrida para o pistol squat."
        },
        commonErrors: ["Curvar a lombar.", "Levantar os calcanhares do chão.", "Joelho valgo (joelhos caindo para dentro)."]
    },
    {
        id: 'cal-l-sit',
        name: 'L-Sit',
        muscleGroup: 'Core',
        category: WorkoutCategory.Calisthenics,
        execution: [
            "Sente-se no chão com as pernas estendidas e as mãos ao lado do quadril, com os dedos apontados para a frente.",
            "Pressione as mãos no chão, travando os cotovelos e elevando o quadril e as pernas do chão.",
            "Mantenha as pernas retas e paralelas ao chão, formando um 'L' com o corpo.",
            "Sustente a posição pelo tempo desejado."
        ],
        tips: ["Deprima as escápulas (empurre os ombros para baixo, longe das orelhas).", "Aponte os pés para a frente."],
        adaptations: {
            beginner: "Comece com os joelhos dobrados (tuck L-sit) ou com uma perna estendida de cada vez.",
            intermediate: "Faça o L-sit padrão no chão ou em paralelas.",
            advanced: "Progrida para o V-sit, elevando as pernas acima da linha do quadril."
        },
        commonErrors: ["Ombros encolhidos.", "Dobrar os joelhos (se o objetivo for o L-sit completo).", "Costas curvadas."]
    },
    // --- GYM ---
    {
        id: 'gym-benchpress',
        name: 'Supino Reto',
        muscleGroup: 'Peito',
        category: WorkoutCategory.Gym,
        execution: [
            "Deite-se no banco com os pés firmes no chão.",
            "Segure a barra com as mãos um pouco mais afastadas que a largura dos ombros.",
            "Retraia as escápulas e crie um leve arco na lombar.",
            "Abaixe a barra de forma controlada até tocar o meio do peito.",
            "Empurre a barra para cima de forma explosiva até a posição inicial."
        ],
        tips: ["Mantenha os glúteos no banco durante todo o movimento.", "Os cotovelos devem ficar em um ângulo de aproximadamente 75 graus em relação ao tronco."],
        adaptations: {
            beginner: "Use halteres para aprender o movimento ou comece com a barra vazia.",
            intermediate: "Use uma carga desafiadora para a faixa de repetições desejada.",
            advanced: "Incorpore pausas no peito ou use técnicas como drop sets."
        },
        commonErrors: ["Quicar a barra no peito.", "Levantar o quadril do banco.", "Abrir demais os cotovelos."]
    },
    {
        id: 'gym-deadlift',
        name: 'Levantamento Terra',
        muscleGroup: 'Costas', // Primarily posterior chain, but often categorized with back
        category: WorkoutCategory.Gym,
        execution: [
            "Posicione-se com os pés na largura do quadril, com a barra sobre o meio dos pés.",
            "Agache e segure a barra com as mãos um pouco por fora das pernas.",
            "Mantenha as costas retas, o peito para cima e o quadril baixo.",
            "Inicie o movimento empurrando o chão com as pernas, mantendo a barra próxima ao corpo.",
            "Quando a barra passar dos joelhos, estenda o quadril e fique totalmente ereto.",
            "Retorne a barra ao chão de forma controlada, invertendo o movimento."
        ],
        tips: ["Pense em 'empurrar o chão para longe' em vez de 'puxar a barra'.", "Mantenha o core travado durante todo o levantamento."],
        adaptations: {
            beginner: "Comece com kettlebell swings para aprender o movimento do quadril ou use halteres.",
            intermediate: "Levantamento terra convencional com barra.",
            advanced: "Varie com terra sumô ou terra romeno (stiff) para focar em diferentes músculos."
        },
        commonErrors: ["Arredondar a lombar.", "Começar o movimento com o quadril subindo antes do resto do corpo.", "Manter a barra longe do corpo."]
    },
    {
        id: 'gym-legpress',
        name: 'Leg Press',
        muscleGroup: 'Pernas',
        category: WorkoutCategory.Gym,
        execution: [
            "Sente-se na máquina e posicione os pés na plataforma, na largura dos ombros.",
            "Abaixe a plataforma de forma controlada, dobrando os joelhos até formar um ângulo de 90 graus.",
            "Mantenha a lombar e o quadril em contato com o banco.",
            "Empurre a plataforma de volta à posição inicial, sem travar completamente os joelhos no topo."
        ],
        tips: ["Ajuste a posição dos pés na plataforma para focar em diferentes músculos (mais altos para glúteos e isquiotibiais, mais baixos para quadríceps)."],
        adaptations: {
            beginner: "Use uma carga leve e foque na amplitude completa do movimento.",
            intermediate: "Aumente a carga progressivamente.",
            advanced: "Experimente variações unilaterais (uma perna de cada vez)."
        },
        commonErrors: ["Tirar o quadril do banco na descida.", "Usar uma amplitude de movimento muito curta.", "Travar os joelhos no final do movimento."]
    },
    // ... Add more exercises to reach 100+
];
